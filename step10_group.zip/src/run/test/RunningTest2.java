package run.test;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Test;

import lombok.extern.slf4j.Slf4j;
import model.domain.Attendance;
import model.domain.Kid;
import model.domain.Teacher;
//child기준에서. 
@Slf4j
public class RunningTest2 {
//create
	@Test
	public static void createEntity() {
		log.info("crud ----create------------\n");
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("step10_group");
		
		EntityManager entitymanager = emfactory.createEntityManager();
		//entitymanager.getTransaction().begin();

		
		try {
					
			makeData(entitymanager);
			//get list
			//Query query = entitymanager.createQuery( "쿼리문 입력하는 곳");
			//List list = query.getResultList();
			//printList(list);
			//syso
			
			
//			Class classroom = Class.builder().classId(55).className("별반").classAge(5).build();
//			entitymanager.persist(classroom);
//			Teacher t1 = Teacher.builder().teacherName("별반").classId(55).build();
//			entitymanager.persist(t1);
//			Kid k1 = Kid.builder().kidId(801).kidName("김혜경").age(5).teacherId(1111).build();
//			entitymanager.persist(k1);
//			entitymanager.getTransaction().commit();
			

		} catch (Exception e) {
			log.warn("입력 불가");
			entitymanager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			entitymanager.close();
		}
		emfactory.close();
	}
	//dummydata 입력
	public static void makeData(EntityManager entitymanager) {
		entitymanager.getTransaction().begin();
		//Attendance att = Attendance.builder().kidId(36).atCount(2).abCount(3).abDate("2020-12-12").build();
		//조회 날짜를 기준으로 kidId, 출석일 수, 오늘 출석 여부, 결석일수, 결석 가장 최근 결석 날짜가 조회됨. 
		entitymanager.persist(new Attendance (36, 2, "YES", 3,"2020-12-10"));
		entitymanager.persist(new Attendance (37, 2, "YES", 3,"2020-12-9"));
		entitymanager.persist(new Attendance (38, 5, "YES",0, "noabsence"));
		entitymanager.persist(new Attendance (39, 2, "NO", 3,"2020-12-12"));
		entitymanager.flush();
		entitymanager.getTransaction().commit();
	}
	

	
//update

	@Test
	public static void updateEntity() {
		log.info("crud ------update------------\n");
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("step10_group");
		EntityManager entitymanager = emfactory.createEntityManager();
		entitymanager.getTransaction().begin();

		try {

			//makeData();
			//updateEntity(37);
			//Employee e1 = entitymanager.find(Employee.class, 1201);
			Attendance child1 = entitymanager.find(Attendance.class, 37);

			// before update
			System.out.println("update 전 (이번 달 1일부터의 출석 조회) : " + child1);
			//결석날짜(오늘날짜)추가 -> 출석정보변경
			//countmethod만들지 고려
			child1.setAtCount(-1);
			child1.setAbCount(1);
			child1.setAtCheck("NO");
			child1.setAbDate("2020-12-12");
			entitymanager.persist(child1);
			entitymanager.merge(child1); //해당 entity 클래스의 인스턴스를 지정하여 해당 엔티티 값을 최신 상태로 업뎃
			entitymanager.flush();
			entitymanager.getTransaction().commit();
//update에서 신규 작성과 달리, find에서 특정 ID의 엔티티를 얻어서, merge 업데이트 처리를 하면 된다!			

			// after update
			System.out.println("update 후(이번 달 1일부터의 출석 조회)" + child1);

		} catch (Exception e) {
			log.warn("입력 불가");
			entitymanager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			entitymanager.close();
		}
		emfactory.close();
	}
	
	
	

	@Test
	public static void findElement() {
		log.info("crud------find-----------\n");
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("step10_group");
		EntityManager entitymanager = emfactory.createEntityManager();
		entitymanager.getTransaction().begin();

		try {
			Attendance child = entitymanager.find(Attendance.class, 37);

			if (child != null) {
				System.out.println("출력: 원아 ID = " + child.getKidId());
				System.out.println("이번 달 출석 일수 = " + child.getAtCount());
				System.out.println("당일 출석 여부 = " + child.getAbCount());
				System.out.println("다음 달 출석 일수 = " + child.getAbDate());
			} else {
				System.out.println("해당 직원은 존재하지 않습니다!!!!!!!!!!");
			}
			entitymanager.getTransaction().commit();
		} catch (Exception e) {
			log.warn("입력 불가");
			entitymanager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			entitymanager.close();
		}
		emfactory.close();
	}

// delete
	@Test
	public static void deleteElement() {
		log.info("crud -----delete-----------\n");
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("step10_group");
		EntityManager entitymanager = emfactory.createEntityManager();

		entitymanager.getTransaction().begin();
		try {
			Attendance child = entitymanager.find(Attendance.class, 38);
			entitymanager.remove(child);

			entitymanager.getTransaction().commit();

		} catch (Exception e) {
			log.warn("입력 불가");
			entitymanager.getTransaction().rollback();
			e.printStackTrace();
		} finally {
			entitymanager.close();
		}
		emfactory.close();
	}

	//
	//public static void main(String[] args) {
	@Test
	public void test() {
		createEntity(); // 실행 직후 none로 대체하기
		updateEntity();
		findElement();
		deleteElement();

	}

}
