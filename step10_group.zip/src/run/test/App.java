package run.test;

import org.junit.jupiter.api.Test;

public class App {
	@Test
	public static void main(String[] args) {
	
			RunningTest.createEmployee(); // 실행 직후 none로 대체하기
			RunningTest.updateEmployee();
			RunningTest.findElement();
			RunningTest.deleteElement();
			
			
			
			
			

	}

}
