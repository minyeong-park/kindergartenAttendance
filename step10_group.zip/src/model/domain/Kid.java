package model.domain;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Entity
public class Kid {

	   @Id
	   //@Column(name="empno")
	   private int kidId;
	   
	  //@Column(name="ename", length=20, nullable=false)
	   private String kidName;
	   
	  // @Column(name="Age", nullable=false)
	   private int age;
	   
	   private char gender; 
	   
	   @ManyToOne(fetch = FetchType.LAZY) 
	   @JoinColumn(name = "teacherId")
	   private Teacher teacherId;	   
	   //Member table의 컬럼명 + 선언된 변수 타입의 pk와 연계되는 fk
	   //private Dept01 deptno;
	   
	   @OneToOne
	   @JoinColumn(name="kidId")
	   private Attendance attendance;
}
