package model.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Entity
public class Attendance {

	  @Id
	  //@OneToOne
	  private int kidId;
	   
	  //@Column(name="ename", length=20, nullable=false)
	  private int atCount;
	  
	  private String atCheck;

	  // @Column(name="Age", nullable=false)
	  private int abCount;
	   @Column(name = "abDate",nullable= true)
	   private String abDate; 
	   
	   @OneToOne(mappedBy="attendance")
	   private Kid kid;
	  
	
}
