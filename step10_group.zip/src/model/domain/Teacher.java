package model.domain;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Entity
public class Teacher {

	 @Id
	 @Column(name="teacherId")
	 private int teacherId;
	   
	 //@Column(name="ename", length=20, nullable=false)
	 private String teacherName;
	   
	  // @Column(name="Age", nullable=false)
	 private int age;
	   
	 @OneToOne//Member to Team 즉 Member 하나가 Team 하나에 소속
	 @JoinColumn(name = "classId") //Member table의 컬럼명 + 선언된 변수 타입의 pk와 연계되는 fk
	 private Class classId;	   //@ManyToOne(fetch = FetchType.LAZY) 
	 
	 @OneToMany(mappedBy="teacherId")
	 private List<Kid> kids;
		
	 public int getKidsCount() {
			return kids.size();
		}
		
	
	
	
	
}
