package model.domain;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
public class Class {


	
	@Id
	@Column(name="classId")
	@OneToOne(mappedBy="teacherId")
	private int classId;
	
	@Column(name="className")
	private String calssName;
	
	@Column(name="classAge")
	private int classAge;
	
	//@OneToMany(mappedBy="classId")
//	@OneToOne(mappedBy="classId")
//	private List<Teacher> teachers;
//	
//	public int getTeacherCount() {
//		return teachers.size();
//	}
	
	
	
}
